
from django.http import JsonResponse
from django.shortcuts import render
from django.core.paginator import Paginator,PageNotAnInteger, EmptyPage
from django.views.decorators.csrf import csrf_exempt
from user.models import *



def GetReaderList(request):
    if request.method == 'GET':
        qparam = request.GET.get('qparam')
        query = request.GET.get('query')
        pagenum = request.GET.get('pagenum')
        pagesize = request.GET.get('pagesize')
        if qparam == "1":
            Result = User.objects.filter(uName__contains = query)
        elif qparam == "2":
            Result = User.objects.filter(uID__contains = query)
        else:
            return JsonResponse({'Fail': 'qparamFalse'})
        
        userResult=list(Result.values('uName','uID','uPhone','uCharacter'))
        paginator = Paginator(userResult, pagesize)
        try:
            userINFO = paginator.page(pagenum)
        except PageNotAnInteger as e:
            userINFO = paginator.page(1)                        # pagenum不是整数->返回第一页数据
        except EmptyPage as e:
            if int(pagenum) > paginator.num_pages:
                userINFO = paginator.page(paginator.num_pages)  # pagenum大于页码范围->获取最后一页数据
            else:
                userINFO = paginator.page(1)                    # pagenum小于页码范围->获取第一页数据

        return JsonResponse(list(userINFO),safe=False)
        #return JsonResponse({'Success': 'Success'})
    else:
        return JsonResponse({})

@csrf_exempt
def AdminChangeUPhone(request):
    if request.method == 'POST':
        uid = request.POST.get('uID')
        newPhone = request.POST.get('uPhone')
        if uid is None:
            return JsonResponse({'success': False, 'message': 'uid未输入'})
        elif newPhone is None:
            return JsonResponse({'success': False, 'message': '新手机号未输入'})
        elif len(newPhone) != 11:
            return JsonResponse({'success': False, 'message': '手机号违规'})
        elif newPhone.isdigit() == False :
            return JsonResponse({'success': False, 'message': '手机号违规'})
        else:
            usr = User.objects.filter(uID=uid)
            if len(usr) == 0:
                return JsonResponse({'success': False, 'message': '用户不存在'})
            else:
                usr.update(uPhone = newPhone)
                return JsonResponse({'success': True, 'message': '更新成功'})
    else:
        return JsonResponse({})