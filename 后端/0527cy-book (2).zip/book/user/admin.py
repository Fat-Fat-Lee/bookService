from django.contrib import admin
from user.models import *


# Register your models here.

class UserAdmin(admin.ModelAdmin):
    list_display = ['uName', 'uID', 'uPWD', 'uPhone', 'uCharacter']


admin.site.register(User, UserAdmin)


class BookAdmin(admin.ModelAdmin):
    list_display = ['bID', 'bName', 'bYear', 'bTotal', 'bLeft']


admin.site.register(BookType, BookAdmin)


class SingleBookAdmin(admin.ModelAdmin):
    list_display = ['bID', 'bSingleID', 'bCondition']


admin.site.register(SingleBook, SingleBookAdmin)