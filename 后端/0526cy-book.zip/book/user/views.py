from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from user.models import User
from user.models import BookType
from user.models import SingleBook
import random
import string
'''
注册：前端提供账号、姓名、密码和确认密码；
后端检查账号重复性、密码是否相同
返回：Json数据success、message
'''


def register(request):
    if request.method == 'POST':
        new_uid = request.POST.get('uid')
        new_name = request.POST.get('username')
        new_pwd1 = request.POST.get('password1')
        new_pwd2 = request.POST.get('password2')
        new_tel = request.POST.get('tel')
        if new_uid is None:
            return JsonResponse({'success': False, 'message': '未输入'})
        else:
            space = User.objects.filter(uID=new_uid)
            if len(space) > 0:
                return JsonResponse({'success': False, 'message': '账号已存在'})
            else:
                if new_pwd2 != new_pwd1:
                    return JsonResponse({'success': False, 'message': '两次密码不一致'})
                else:
                    new_student = User()
                    new_student.uID = new_uid
                    new_student.uName = new_name
                    new_student.uPWD = new_pwd1
                    new_student.uPhone = new_tel
                    new_student.uCharacter = False
                    new_student.save()
                    return JsonResponse({'success': True, 'message': '注册成功'})
    else:
        return JsonResponse({})


'''
登录：前端提供账号、密码；
后端在数据库中检查账号存在性，验证密码正确性和身份
返回Json数据：success、message、isManager
'''


def login(request):
    if request.method == 'POST':
        log_uid = request.POST.get('uid')
        password = request.POST.get('password')
        user = User.objects.filter(uID=log_uid)  # 从数据库查询
        if len(user) == 0:
            return JsonResponse({'success': False, 'message': '用户不存在', 'isManager': False})
        else:
            if user[0].uPWD == password:
                request.session['username'] = log_uid
                if not user[0].uCharacter:
                    return JsonResponse({'success': True, 'message': '登陆成功', 'isManager': False})
                else:
                    return JsonResponse({'success': True, 'message': '登陆成功', 'isManager': True})
            else:
                return JsonResponse({'success': False, 'message': '密码错误', 'isManager': False})
    else:
        return JsonResponse({})


'''
管理员添加读者：前端提供读者姓名、账号、密码和手机号
后端：检查账号重复性，将信息加入数据库
返回：Json数据success、message
'''


def OperatorAddReader(request):
    if request.method == 'POST':
        new_uid = request.POST.get('uid')
        new_name = request.POST.get('username')
        new_pwd1 = request.POST.get('password')
        new_tel = request.POST.get('tel')
        if new_uid is None:
            return JsonResponse({'success': False, 'message': '未输入'})
        else:
            space = User.objects.filter(uID=new_uid)
            if len(space) > 0:
                return JsonResponse({'success': False, 'message': '账号已存在'})
            else:
                new_student = User()
                new_student.uID = new_uid
                new_student.uName = new_name
                new_student.uPWD = new_pwd1
                new_student.uPhone = new_tel
                new_student.uCharacter = False
                new_student.save()
                return JsonResponse({'success': True, 'message': '添加成功'})
    else:
        return JsonResponse({})


'''
管理员删除读者：前端提供账号，后端检查账号存在性，删除对应读者信息
'''


def OperatorDeleteReader(request):
    if request.method == 'POST':
        del_uid = request.POST.get('uid')
        if del_uid is None:
            return JsonResponse({'success': False, 'message': '未输入'})
        else:
            space = User.objects.filter(uID=del_uid)
            if len(space) == 0:
                return JsonResponse({'success': False, 'message': '不存在此账号'})
            else:
                User.objects.filter(uID=del_uid).delete()
                return JsonResponse({'success': True, 'message': '删除成功'})
    else:
        return JsonResponse({})


'''
管理员获取读者列表
'''


def GetReaderList(request):
    if request.method == 'GET':
        qparam = request.GET.get('qparam')
        query = request.GET.get('query')
        pagenum = request.GET.get('pagenum')
        pagesize = request.GET.get('pagesize')
        if qparam == "1":
            Result = User.objects.filter(uName__contains=query)
        elif qparam == "2":
            Result = User.objects.filter(uID__contains=query)
        else:
            return JsonResponse({'Fail': 'qparamFalse'})

        userResult = list(Result.values('uName', 'uID', 'uPhone', 'uCharacter'))
        paginator = Paginator(userResult, pagesize)
        try:
            userINFO = paginator.page(pagenum)
        except PageNotAnInteger as e:
            userINFO = paginator.page(1)  # pagenum不是整数->返回第一页数据
        except EmptyPage as e:
            if int(pagenum) > paginator.num_pages:
                userINFO = paginator.page(paginator.num_pages)  # pagenum大于页码范围->获取最后一页数据
            else:
                userINFO = paginator.page(1)  # pagenum小于页码范围->获取第一页数据

        return JsonResponse(list(userINFO), safe=False)
        # return JsonResponse({'Success': 'Success'})
    else:
        return JsonResponse({})


@csrf_exempt
def AdminChangeUPhone(request):
    if request.method == 'POST':
        uid = request.POST.get('uID')
        newPhone = request.POST.get('uPhone')
        if uid is None:
            return JsonResponse({'success': False, 'message': 'uid未输入'})
        elif newPhone is None:
            return JsonResponse({'success': False, 'message': '新手机号未输入'})
        elif len(newPhone) != 11:
            return JsonResponse({'success': False, 'message': '手机号违规'})
        elif newPhone.isdigit() == False:
            return JsonResponse({'success': False, 'message': '手机号违规'})
        else:
            usr = User.objects.filter(uID=uid)
            if len(usr) == 0:
                return JsonResponse({'success': False, 'message': '用户不存在'})
            else:
                usr.update(uPhone=newPhone)
                return JsonResponse({'success': True, 'message': '更新成功'})
    else:
        return JsonResponse({})


'''
读者修改个人信息
'''


def ReaderChangePWD(request):
    if request.method == 'POST':
        ID = request.POST.get('uID')
        PWD = request.POST.get('uPWD')
        checkPWD = request.POST.get('ucheckPWD')
        if ID is None or PWD is None or checkPWD is None:
            return JsonResponse({'success': False, 'message': '信息不完整'})
        else:
            space = User.objects.filter(uID=ID)
            if len(space) == 0:
                return JsonResponse({'success': False, 'message': '账号不存在'})
            else:
                usr = User.objects.filter(uID=ID)
                if PWD!=checkPWD:
                    return JsonResponse({'success': False, 'message': '两次密码不一致'})
                else:
                    usr.update(uPWD=PWD)
                    return JsonResponse({'success': True, 'message': '密码修改成功'})
    else:
        return JsonResponse({})


def ReaderChangeInfo(request):
    if request.method == 'POST':
        ID = request.POST.get('uID')
        name = request.POST.get('uName')
        Phone = request.POST.get('uPhone')
        if ID is None or name is None or Phone is None:
            return JsonResponse({'success': False, 'message': '信息不完整'})
        else:
            space = User.objects.filter(uID=ID)
            if len(space) == 0:
                return JsonResponse({'success': False, 'message': '账号不存在'})
            else:
                usr = User.objects.filter(uID=ID)
                usr.update(uName=name, uPhone=Phone)
                return JsonResponse({'success': True, 'message': '信息修改成功'})
    else:
        return JsonResponse({})


'''
管理员添加图书类
'''


def AddBookType(request):
    if request.method == 'POST':
        name = request.POST.get('bName')
        year = request.POST.get('bYear')
        author = request.POST.get('bAuthor')
        total = request.POST.get('bTotal')
        left = request.POST.get('bLeft')
        if name is None or year is None or author is None or total is None or left is None:
            return JsonResponse({'success': False, 'message': '信息不完整'})
        else:
            space = BookType.objects.filter(bName=name, bYear=year, bAuthor=author)
            if len(space) > 0:
                return JsonResponse({'success': False, 'message': '该图书已存在'})
            else:
                new_booktype = BookType()

                id = ''.join(random.sample(string.ascii_letters + string.digits, 8))
                space1 = BookType.objects.filter(bID=id)
                while space1 > 0:
                    id = ''.join(random.sample(string.ascii_letters + string.digits, 8))
                    space1 = BookType.objects.filter(bID=id)

                new_booktype.bID = id
                new_booktype.bName = name
                new_booktype.bYear = year
                new_booktype.bAuthor = author
                new_booktype.bTotal = total
                new_booktype.bLeft = left
                new_booktype.save()
                for i in range(total):
                    new_book = SingleBook()

                    singleid = ''.join(random.sample(string.ascii_letters + string.digits, 11))
                    space1 = BookType.objects.filter(bID=singleid)
                    while space1 > 0:
                        singleid = ''.join(random.sample(string.ascii_letters + string.digits, 11))
                        space1 = BookType.objects.filter(bID=singleid)

                    new_book.bID = ID
                    new_book.bSingleID = singleid
                    new_book.save()
                return JsonResponse({'success': True, 'message': '图书添加成功'})
    else:
        return JsonResponse({})


'''
管理员删除图书类
'''


def DeleteBookType(request):
    if request.method == 'POST':
        ID = request.POST.get('bID')
        if ID is None:
            return JsonResponse({'success': False, 'message': '信息不完整'})
        else:
            space = BookType.objects.filter(bID=id)
            if space == 0:
                return JsonResponse({'success': False, 'message': '找不到该图书'})
            else:
                books = SingleBook.objects.filter(bID=id)
                if books > 0:
                    for book in books:
                        if book.bCondition == False:
                            return JsonResponse({'success': False, 'message': '还有书没还'})
                    SingleBook.objects.filter(bID=id).delete()
                BookType.objects.filter(bID=id).delete()
                return JsonResponse({'success': True, 'message': '图书删除成功'})
    else:
        return JsonResponse({})


'''
管理员修改图书类
'''


def ChangeBookType(request):
    if request.method == 'POST':
        ID = request.POST.get('bID')
        name = request.POST.get('bName')
        year = request.POST.get('bYear')
        author = request.POST.get('bAuthor')
        total = request.POST.get('bTotal')
        if name is None or year is None or author is None or total is None or ID is None:
            return JsonResponse({'success': False, 'message': '信息不完整'})
        else:
            space = BookType.objects.filter(bID=ID)
            if space == 0:
                return JsonResponse({'success': False, 'message': '找不到该图书'})
            else:
                booktype = BookType.objects.filter(bID=ID)
                if booktype.bTotal > total:
                    cnt = booktype.bTotal-total
                    for i in range(cnt):
                        new_book = SingleBook()

                        singleid = ''.join(random.sample(string.ascii_letters + string.digits, 11))
                        space1 = BookType.objects.filter(bID=singleid)
                        while space1 > 0:
                            singleid = ''.join(random.sample(string.ascii_letters + string.digits, 11))
                            space1 = BookType.objects.filter(bID=singleid)

                        new_book.bID = ID
                        new_book.bSingleID = singleid
                        new_book.save()
                booktype.update(bName=name, bYear=year, bAuthor=author, bTaotal=total)
                return JsonResponse({'success': True, 'message': '图书信息修改成功'})
    else:
        return JsonResponse({})


'''
管理员删除单本图书
'''


def DeleteSingleBook(request):
    if request.method == 'POST':
        singleID = request.POST.get('bSingleID')
        if singleID is None:
            return JsonResponse({'success': False, 'message': '参数不全'})
        else:
            space = SingleBook.objects.filter(bSingleID=singleID)
            if space == 0:
                return JsonResponse({'success': False, 'message': '找不到该本图书'})
            else:
                book =SingleBook.objects.get(bSingleID=singleID)
                bID = book.bID
                booktype = BookType.objects.filter(bID=bID)
                total = booktype.bTotal
                booktype.update(bTotal=total-1)
                SingleBook.objects.filter(bSingleID=singleID).delete()
                return JsonResponse({'success': True, 'message': '图书删除成功'})
    else:
        return JsonResponse({})


'''
获取图书列表
'''


def GetBookList(request):
    if request.method == 'GET':
        qparam = request.GET.get('qparam')
        query = request.GET.get('query')
        qsort = request.GET.get('qsort')
        pagenum = request.GET.get('pagenum')
        pagesize = request.GET.get('pagesize')
        if qsort == "11":
            BookType.objects.order_by("bID")
        elif qsort == "21":
            BookType.objects.order_by("bName")
        elif qsort == "31":
            BookType.objects.order_by("bYear")
        elif qsort == "41":
            BookType.objects.order_by("bTotal")
        if qparam == "1":
            Result = BookType.objects.filter(bName__contains=query)
        elif qparam == "2":
            Result = BookType.objects.filter(bID__contains=query)
        elif qparam == "3":
            Result = BookType.objects.filter(bAuthor__contains=query)
        else:
            return JsonResponse({'success': False, 'message': '查询参数错误'})

        bookResult = list(Result.values('bID', 'bName', 'bYear', 'bTotal', 'bLeft'))
        paginator = Paginator(bookResult, pagesize)
        try:
            bookINFO = paginator.page(pagenum)
        except PageNotAnInteger as e:
            bookINFO = paginator.page(1)  # pagenum不是整数->返回第一页数据
        except EmptyPage as e:
            if int(pagenum) > paginator.num_pages:
                bookINFO = paginator.page(paginator.num_pages)  # pagenum大于页码范围->获取最后一页数据
            else:
                bookINFO = paginator.page(1)  # pagenum小于页码范围->获取第一页数据

        return JsonResponse(list(bookINFO), safe=False)
    else:
        return JsonResponse({})