from django.contrib import admin
from reader.models import *


# Register your models here.

'''
# Register your models here.
class TagInline(admin.TabularInline):
    model = Tag
 
class ContactAdmin(admin.ModelAdmin):
    inlines = [TagInline]  # Inline
    fieldsets = (
        ['Main',{
            'fields':('name','email'),
        }],
        ['Advance',{
            'classes': ('collapse',),
            'fields': ('age',),
        }]
 
    )
 
admin.site.register(Contact, ContactAdmin)
admin.site.register([Test])
---
class ReaderAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'password', 'isManager']


admin.site.register(Reader, ReaderAdmin)
'''

class ContactReaderAdmin(admin.ModelAdmin):
    fieldsets = (
        ['Main',{
            'fields':( 'name', 'password', 'isManager'),
        }],
        ['Advance',{
            'classes': ('collapse',),
            'fields': ('tel',),
        }]
    )
admin.site.register(Reader, ContactReaderAdmin)
 

