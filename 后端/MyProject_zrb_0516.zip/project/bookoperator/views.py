from django.http import JsonResponse
from django.shortcuts import render
from reader.models import *
from envs.TensorFlow.Lib.pickle import NONE
from _overlapped import NULL

# Create your views here.
# def index(request):
#
#
# def login(request):


# def logout(request):
#
#
# def register(request):


def getReader(request):
    if request.method == 'GET':
        readerResult = list(Reader.objects.values('id','name','isManager'))
        return JsonResponse(readerResult,safe=False)
    else:
        return JsonResponse({})
    
def changePhoneNum(request):
    if request.method == 'POST':
        usrname = request.POST.get('username')
        new_phoneNum = request.POST.get('newPhoneNum')
        if usrname is None:
            return JsonResponse({'success': False, 'message': '用户名未输入'})
        elif new_phoneNum is None:
            return JsonResponse({'success': False, 'message': '新手机号未输入'})
   
        else:
            user = Reader.objects.filter(name=usrname)
            if len(user) == 0:
                return JsonResponse({'success': False, 'message': '用户不存在'})
            else:
                user.update(tel = new_phoneNum)
                if len(new_phoneNum) == 0:
                    return JsonResponse({'success': True, 'message': '更新成功，新手机号为空'})
                else:
                    return JsonResponse({'success': True, 'message': '更新成功'})
                
    else:
        return JsonResponse({})
    
    
    
    
    