from django.contrib import admin
from reader.models import *


# Register your models here.


class ReaderAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'password', 'isManager']


admin.site.register(Reader, ReaderAdmin)
