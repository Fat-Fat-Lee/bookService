from django.http import JsonResponse
from django.shortcuts import render
from reader.models import Reader

# Create your views here.
'''
注册：前端提供用户名、密码和确认密码，暂定用户名不能重复
'''


def register(request):
    if request.method == 'POST':
        new_username = request.POST.get('username')
        new_password1 = request.POST.get('password1')
        new_password2 = request.POST.get('password2')
        if new_username is None:
            return JsonResponse({'success': False, 'message': '未输入'})
        else:
            space = Reader.objects.filter(name=new_username)
            if len(space) > 0:
                return JsonResponse({'success': False, 'message': '用户已存在'})
            else:
                if new_password2 != new_password1:
                    return JsonResponse({'success': False, 'message': '两次密码不一致'})
                else:
                    new_student = Reader()
                    new_student.name = new_username
                    new_student.password = new_password1
                    new_student.save()
                    return JsonResponse({'success': True, 'message': '注册成功'})
    else:
        return JsonResponse({})


def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = Reader.objects.filter(name=username)

        if len(user) == 0:
            return JsonResponse({'success': False, 'message': '用户不存在'})
        else:
            if user[0].password == password:
                request.session['username'] = username
                if not user[0].isManager:
                    return JsonResponse({'success': True, 'message': '登陆成功', 'isManager': False})
                else:
                    return JsonResponse({'success': True, 'message': '登陆成功', 'isManager': True})
            else:
                return JsonResponse({'success': False, 'message': '密码错误'})
    else:
        return JsonResponse({})

# def index(request):
#
#
# def login(request):
#
#
# def logout(request):
#
#
