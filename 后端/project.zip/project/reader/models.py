from django.db import models


# Create your models here.
class Reader(models.Model):
    id = models.AutoField(primary_key=True)  # 主键
    name = models.CharField(max_length=30)  # 姓名
    password = models.CharField(max_length=20)
    isManager = models.BooleanField(default=False)  # 是否是管理员，默认不是


class UserInfo(models.Model):

    IDNumber = models.CharField(max_length=20)
    IDType = models.CharField(max_length=15)
    tel = models.CharField(max_length=20)

    beginTime = models.DateField(auto_now_add=True)  # 办证日期
    endTime = models.DateField  # 失效日期

    maxNum = models.IntegerField(default=5)  # 最大借书量，初始5本


'''
？数据库表存疑
    
'''