from django.db import models


# Create your models here.
class BookOperator(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    password = models.CharField(max_length=20)

    IDNumber = models.CharField(max_length=20)
    IDType = models.CharField(max_length=15)
    tel = models.CharField(max_length=20)

    status = models.BooleanField(default=False)
