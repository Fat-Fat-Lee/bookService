from django.contrib import admin
from bookoperator.models import *
# Register your models here.


class BookOperatorAdmin(admin.ModelAdmin):
    list_display = []


admin.site.register(BookOperator, BookOperatorAdmin)