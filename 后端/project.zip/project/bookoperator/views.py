from django.shortcuts import render

# Create your views here.
# def index(request):
#
#
# def login(request):


# def logout(request):
#
#
# def register(request):
