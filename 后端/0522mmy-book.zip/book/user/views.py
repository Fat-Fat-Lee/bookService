from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from user.models import User

'''
注册：前端提供账号、姓名、密码和确认密码；
后端检查账号重复性、密码是否相同
返回：Json数据success、message
'''


def register(request):
    if request.method == 'POST':
        new_uid = request.POST.get('uid')
        new_name = request.POST.get('username')
        new_pwd1 = request.POST.get('password1')
        new_pwd2 = request.POST.get('password2')
        new_tel = request.POST.get('tel')
        if new_uid is None:
            return JsonResponse({'success': False, 'message': '未输入'})
        else:
            space = User.objects.filter(uID=new_uid)
            if len(space) > 0:
                return JsonResponse({'success': False, 'message': '账号已存在'})
            else:
                if new_pwd2 != new_pwd1:
                    return JsonResponse({'success': False, 'message': '两次密码不一致'})
                else:
                    new_student = User()
                    new_student.uID = new_uid
                    new_student.uName = new_name
                    new_student.uPWD = new_pwd1
                    new_student.uPhone = new_tel
                    new_student.uCharacter = False
                    new_student.save()
                    return JsonResponse({'success': True, 'message': '注册成功'})
    else:
        return JsonResponse({})


'''
登录：前端提供账号、密码；
后端在数据库中检查账号存在性，验证密码正确性和身份
返回Json数据：success、message、isManager
'''


def login(request):
    if request.method == 'POST':
        log_uid = request.POST.get('uid')
        password = request.POST.get('password')
        user = User.objects.filter(uID=log_uid)  # 从数据库查询
        if len(user) == 0:
            return JsonResponse({'success': False, 'message': '用户不存在', 'isManager': False})
        else:
            if user[0].uPWD == password:
                request.session['username'] = log_uid
                if not user[0].uCharacter:
                    return JsonResponse({'success': True, 'message': '登陆成功', 'isManager': False})
                else:
                    return JsonResponse({'success': True, 'message': '登陆成功', 'isManager': True})
            else:
                return JsonResponse({'success': False, 'message': '密码错误', 'isManager': False})
    else:
        return JsonResponse({})


'''
管理员添加读者：前端提供读者姓名、账号、密码和手机号
后端：检查账号重复性，将信息加入数据库
返回：Json数据success、message
'''


def OperatorAddReader(request):
    if request.method == 'POST':
        new_uid = request.POST.get('uid')
        new_name = request.POST.get('username')
        new_pwd1 = request.POST.get('password')
        new_tel = request.POST.get('tel')
        if new_uid is None:
            return JsonResponse({'success': False, 'message': '未输入'})
        else:
            space = User.objects.filter(uID=new_uid)
            if len(space) > 0:
                return JsonResponse({'success': False, 'message': '账号已存在'})
            else:
                new_student = User()
                new_student.uID = new_uid
                new_student.uName = new_name
                new_student.uPWD = new_pwd1
                new_student.uPhone = new_tel
                new_student.uCharacter = False
                new_student.save()
                return JsonResponse({'success': True, 'message': '添加成功'})
    else:
        return JsonResponse({})


'''
管理员删除读者：前端提供账号，后端检查账号存在性，删除对应读者信息
'''


def OperatorDeleteReader(request):
    if request.method == 'POST':
        del_uid = request.POST.get('uid')
        if del_uid is None:
            return JsonResponse({'success': False, 'message': '未输入'})
        else:
            space = User.objects.filter(uID=del_uid)
            if len(space) == 0:
                return JsonResponse({'success': False, 'message': '不存在此账号'})
            else:
                User.objects.filter(uID=del_uid).delete()
                return JsonResponse({'success': True, 'message': '删除成功'})
    else:
        return JsonResponse({})


def GetReaderList(request):
    if request.method == 'GET':
        qparam = request.GET.get('qparam')
        query = request.GET.get('query')
        pagenum = request.GET.get('pagenum')
        pagesize = request.GET.get('pagesize')
        if qparam == "1":
            Result = User.objects.filter(uName__contains=query)
        elif qparam == "2":
            Result = User.objects.filter(uID__contains=query)
        else:
            return JsonResponse({'Fail': 'qparamFalse'})

        userResult = list(Result.values('uName', 'uID', 'uPhone', 'uCharacter'))
        paginator = Paginator(userResult, pagesize)
        try:
            userINFO = paginator.page(pagenum)
        except PageNotAnInteger as e:
            userINFO = paginator.page(1)  # pagenum不是整数->返回第一页数据
        except EmptyPage as e:
            if int(pagenum) > paginator.num_pages:
                userINFO = paginator.page(paginator.num_pages)  # pagenum大于页码范围->获取最后一页数据
            else:
                userINFO = paginator.page(1)  # pagenum小于页码范围->获取第一页数据

        return JsonResponse(list(userINFO), safe=False)
        # return JsonResponse({'Success': 'Success'})
    else:
        return JsonResponse({})


@csrf_exempt
def AdminChangeUPhone(request):
    if request.method == 'POST':
        uid = request.POST.get('uID')
        newPhone = request.POST.get('uPhone')
        if uid is None:
            return JsonResponse({'success': False, 'message': 'uid未输入'})
        elif newPhone is None:
            return JsonResponse({'success': False, 'message': '新手机号未输入'})
        elif len(newPhone) != 11:
            return JsonResponse({'success': False, 'message': '手机号违规'})
        elif newPhone.isdigit() == False:
            return JsonResponse({'success': False, 'message': '手机号违规'})
        else:
            usr = User.objects.filter(uID=uid)
            if len(usr) == 0:
                return JsonResponse({'success': False, 'message': '用户不存在'})
            else:
                usr.update(uPhone=newPhone)
                return JsonResponse({'success': True, 'message': '更新成功'})
    else:
        return JsonResponse({})
